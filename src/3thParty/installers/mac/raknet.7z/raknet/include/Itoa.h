#ifndef __RAK_ITOA_H
#define __RAK_ITOA_H

#ifdef __cplusplus
extern "C" {
#endif

char* Itoa( int value, char* result, int base );

#ifdef __cplusplus
}
#endif


#endif
